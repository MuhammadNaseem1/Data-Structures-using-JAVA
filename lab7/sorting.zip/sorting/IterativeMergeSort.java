package sorting;

public class IterativeMergeSort {
	
	public static <AnyType extends Comparable<? super AnyType>>
	void mergeSort( AnyType [] a) {
		// here goes the student solution
		return;
	}

}
