package sorting;

public class SortingFour {
	
	// assume that the array a only contains four elements:
	// a[0], a[1], a[2], and a[3]
	
	public static <AnyType extends Comparable<? super AnyType>>
	void sortFour( AnyType [] a) {
		// here goes the student solution
		return;
	}
	
}
