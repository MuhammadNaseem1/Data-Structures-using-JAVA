package sorting;

public class TwoSum {

	public static boolean twoSum( int[] a, int k) {
		// here goes the student solution
		return false;
	}

}
